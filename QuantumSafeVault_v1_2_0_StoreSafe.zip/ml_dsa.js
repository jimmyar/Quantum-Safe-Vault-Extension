
import { ml_dsa65 } from './vendor/post-quantum/ml-dsa.js';
export const backend = 'noble 0.4.1';
export function dsaKeypair() {
  const { publicKey, secretKey } = ml_dsa65.keygen();
  return { pk: publicKey, sk: secretKey };
}
