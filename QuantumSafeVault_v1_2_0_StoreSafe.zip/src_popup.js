import { ml_kem768 } from './vendor/post-quantum/ml-kem.js';
import { ml_dsa65 } from './vendor/post-quantum/ml-dsa.js';

const $ = (id) => document.getElementById(id);

// ---- KEM helpers with fallback (encap/decap vs encapsulate/decapsulate) ----
function KEM_encap(pub){
  if (typeof ml_kem768.encap === 'function') return ml_kem768.encap(pub);
  if (typeof ml_kem768.encapsulate === 'function') return ml_kem768.encapsulate(pub);
  throw new Error('ml_kem768 encap/encapsulate not found');
}
function KEM_decap(ct, prv){
function DSA_sign(prv,msg){ if (typeof ml_dsa65.sign==='function') return ml_dsa65.sign(prv,msg); if (typeof ml_dsa65.signDetached==='function') return ml_dsa65.signDetached(prv,msg); throw new Error('ml_dsa65 sign not found'); }
function DSA_verify(pub,msg,sig){ if (typeof ml_dsa65.verify==='function') return ml_dsa65.verify(pub,msg,sig); if (typeof ml_dsa65.verifyDetached==='function') return ml_dsa65.verifyDetached(pub,msg,sig); throw new Error('ml_dsa65 verify not found'); }

  if (typeof ml_kem768.decap === 'function') return ml_kem768.decap(ct, prv);
  if (typeof ml_kem768.decapsulate === 'function') return ml_kem768.decapsulate(ct, prv);
  throw new Error('ml_kem768 decap/decapsulate not found');
}

const te = new TextEncoder();
const td = new TextDecoder();
const hex = (u8) => [...u8].map(b => b.toString(16).padStart(2,'0')).join('');
const unhex = (h) => new Uint8Array(h.match(/.{1,2}/g).map(x => parseInt(x,16)));

// ---- Storage helpers ----
const sget = (keys) => new Promise(res => chrome.storage.local.get(keys, res));
const sset = (obj) => new Promise(res => chrome.storage.local.set(obj, res));

// ---- PIN / Lockout helpers ----
async function sha256(u8){const d=await crypto.subtle.digest('SHA-256',u8);return new Uint8Array(d);}
async function deriveBitsFromPIN(pin, salt){
  const keyMat=await crypto.subtle.importKey('raw', te.encode(pin), 'PBKDF2', false, ['deriveBits']);
  const bits=await crypto.subtle.deriveBits({ name:'PBKDF2', hash:'SHA-256', iterations:200_000, salt }, keyMat, 256);
  return new Uint8Array(bits);
}
async function deriveAESKeyFromPIN(pin, salt){
  const bits=await deriveBitsFromPIN(pin, salt);
  return await crypto.subtle.importKey('raw', bits, { name:'AES-GCM' }, false, ['encrypt','decrypt']);
}
function now(){ return Date.now(); }
function secs(ms){ return Math.max(0, Math.ceil(ms/1000)); }

async function readPINMeta(){ const s=await sget(['pinSalt','pinVerifier','pinFailCount','pinLockUntil']); return s; }

async function ensurePINInteractive(needSet=false){
  const pin = $('pinInput').value || '';
  if (!pin) throw new Error('Enter your PIN');
  const meta = await readPINMeta();
  const fails = meta.pinFailCount|0;
  const until = meta.pinLockUntil|0;
  if (until && now() < until) {
    const left = secs(until - now());
    throw new Error(`Locked. Try again in ${left}s`);
  }
  if (!meta.pinSalt || !meta.pinVerifier) {
    if (!needSet) throw new Error('No PIN set. Generate keys first.');
    const salt = crypto.getRandomValues(new Uint8Array(16));
    const bits = await deriveBitsFromPIN(pin, salt);
    const verifier = await sha256(bits);
    await sset({ pinSalt: Array.from(salt), pinVerifier: Array.from(verifier), pinFailCount: 0, pinLockUntil: 0 });
    return pin;
  } else {
    const bits = await deriveBitsFromPIN(pin, new Uint8Array(meta.pinSalt));
    const digest = await sha256(bits);
    const ok = hex(digest) === hex(new Uint8Array(meta.pinVerifier));
    if (!ok) {
      const nf = (fails+1);
      let upd = { pinFailCount: nf };
      if (nf >= 3) upd.pinLockUntil = now() + 15*60*1000;
      await sset(upd);
      throw new Error(nf >= 3 ? 'Too many attempts. Locked for 15 minutes.' : `Wrong PIN (${nf}/3)`);
    }
    if (fails) await sset({ pinFailCount: 0, pinLockUntil: 0 });
    return pin;
  }
}

// ---- Vault key sealing ----
async function encryptWithPIN(pin, plain){
  const salt = crypto.getRandomValues(new Uint8Array(16));
  const iv = crypto.getRandomValues(new Uint8Array(12));
  const akey = await deriveAESKeyFromPIN(pin, salt);
  const ct = new Uint8Array(await crypto.subtle.encrypt({ name:'AES-GCM', iv }, akey, plain));
  return { ct:Array.from(ct), iv:Array.from(iv), salt:Array.from(salt) };
}
async function decryptWithPIN(pin, bundle){
  const { ct, iv, salt } = bundle;
  const akey = await deriveAESKeyFromPIN(pin, new Uint8Array(salt));
  return new Uint8Array(await crypto.subtle.decrypt({ name:'AES-GCM', iv:new Uint8Array(iv) }, akey, new Uint8Array(ct)));
}

// ---- Key management ----
function kyberKeypair(){ const { publicKey, secretKey } = ml_kem768.keygen(); return { publicKey, privateKey: secretKey }; }
function dilithiumKeypair(){ const { publicKey, secretKey } = ml_dsa65.keygen(); return { publicKey, privateKey: secretKey }; }

async function haveKeys(){
  const s = await sget(['kyber','dili']);
  return !!(s.kyber?.pub && s.kyber?.prv);
}
async function generateKeys(){
  const pin = await ensurePINInteractive(true);
  const { publicKey: kpub, privateKey: kprv } = kyberKeypair();
  const { publicKey: dpub, privateKey: dprv } = dilithiumKeypair();
  const kb = await encryptWithPIN(pin, kprv);
  const db = await encryptWithPIN(pin, dprv);
  await sset({ kyber: { pub: Array.from(kpub), prv: kb }, dili: { pub: Array.from(dpub), prv: db } });
}

// ---- PQC encrypt/decrypt primitives ----
async function pqcEncryptBytes(plainU8, pubOverride){
  const s = await sget(['kyber','dili']);
  if (!s.kyber?.pub) throw new Error('Keys not generated yet');
  const pub = pubOverride ? new Uint8Array(pubOverride) : new Uint8Array(s.kyber.pub);
  const { cipherText, sharedSecret } = KEM_encap(pub);
  const aes = await crypto.subtle.importKey('raw', sharedSecret, { name:'AES-GCM' }, false, ['encrypt']);
  const iv = crypto.getRandomValues(new Uint8Array(12));
  const ct = new Uint8Array(await crypto.subtle.encrypt({ name:'AES-GCM', iv }, aes, plainU8));
  const base={ kemCt: hex(cipherText), iv: hex(iv), ct: hex(ct), ver:'pqc-v1', scheme:'ML-KEM-768+AES-GCM' };
try{ if(s.dili?.prv && s.dili?.pub){ const pin=await ensurePINInteractive(false); const prv=await decryptWithPIN(pin, s.dili.prv); const msg=new TextEncoder().encode(JSON.stringify(base)); const sig=DSA_sign(prv, msg); base.from=hex(new Uint8Array(s.dili.pub)); base.sig=hex(sig);} }catch(e){ console.warn('sign skipped',e); }
return base;
}
async function pqcDecryptBytes(bundle){
  const s = await sget(['kyber','dili']);
  if (!s.kyber?.prv) throw new Error('No private key available');
  const pin = await ensurePINInteractive(false);
  const prv = await decryptWithPIN(pin, s.kyber.prv);
  const shared = KEM_decap(unhex(bundle.kemCt), prv);
  const aes = await crypto.subtle.importKey('raw', shared, { name:'AES-GCM' }, false, ['decrypt']);
  const pt = new Uint8Array(await crypto.subtle.decrypt({ name:'AES-GCM', iv: unhex(bundle.iv) }, aes, unhex(bundle.ct)));
  return pt;
}

// ---- UI state ----
async function refreshUI(){
  const keysExist = await haveKeys();
  const showCreate = !keysExist;
  const byId=(id)=>document.getElementById(id);
  if (byId('forceCreateRow')) byId('forceCreateRow').classList.toggle('hidden', !showCreate);
  if (byId('firstRun')) byId('firstRun').classList.add('hidden');
  if (byId('mainActions')) byId('mainActions').classList.toggle('hidden', showCreate);
  if (byId('modeChooser')) byId('modeChooser').classList.add('hidden');
  if (byId('textPanel')) byId('textPanel').classList.add('hidden');
  if (byId('doText')) byId('doText').dataset.mode = 'encrypt';
  if (byId('textPanelTitle')) byId('textPanelTitle').textContent = 'Encrypt Text';
}
async function updateLockStatus(){
  const meta = await readPINMeta();
  const until = meta.pinLockUntil|0;
  const el = $('lockStatus');
  if (!el) return;
  if (until && now() < until) {
    const left = Math.ceil((until - now())/1000);
    el.innerHTML = `<span class="countdown">Locked for ${left}s</span>`;
    setTimeout(updateLockStatus, 1000);
  } else {
    el.textContent = '';
  }
}

// ---- File save helper ----
function downloadBlobPrompt(blob, suggestedName){
  const url = URL.createObjectURL(blob);
  if (chrome && chrome.downloads && chrome.downloads.download) {
    chrome.downloads.download({ url, filename: suggestedName, saveAs: true });
    setTimeout(() => URL.revokeObjectURL(url), 10000);
    return;
  }
  const a = document.createElement('a');
  a.href = url; a.download = suggestedName; a.click();
  setTimeout(() => URL.revokeObjectURL(url), 10000);
}


async function popupCreateKeysGuarded(){
  const s = await sget(['kyber','dili']);
  if (s.kyber?.pub && s.kyber?.prv) {
    alert('Keys already exist. To regenerate, go to Options & Advanced.');
    return;
  }
  await generateKeys();
  await refreshUI();
  alert('Keys generated');
}

// ---- Event handlers ----
$('btnGenTop')?.addEventListener('click', async () => { try { await popupCreateKeysGuarded(); } catch(e){ alert(e.message||String(e)); } });
if ($('btnEncrypt')) $('btnEncrypt').addEventListener('click', () => {
  $('modeChooser').classList.remove('hidden');
  $('textPanel').classList.add('hidden');
  $('textPanelTitle').textContent = 'Encrypt Text';
  $('doText').textContent = 'Encrypt';
  $('doText').dataset.mode = 'encrypt';
});
if ($('btnDecrypt')) $('btnDecrypt').addEventListener('click', () => {
  $('modeChooser').classList.remove('hidden');
  $('textPanel').classList.add('hidden');
  $('textPanelTitle').textContent = 'Decrypt Text';
  $('doText').textContent = 'Decrypt';
  $('doText').dataset.mode = 'decrypt';
});

if ($('modeFiles')) $('modeFiles').addEventListener('click', async () => {
  const mode = ($('doText')?.dataset?.mode === 'decrypt') ? 'decrypt' : 'encrypt';
  const url = chrome?.runtime?.getURL ? chrome.runtime.getURL('src_fullpage.html') : 'src_fullpage.html';
  const target = url + (mode ? ('#' + mode) : '');
  try { window.open(target, '_blank'); } catch (e) { try { chrome.tabs.create({ url: target }); } catch {} }
});
  if ($('modeText')) if ($('modeText')) $('modeText').addEventListener('click', () => {
  if ($('textPanel')) $('textPanel').classList.remove('hidden');
  if ($('textOut')) $('textOut').classList.add('hidden'); if ($('copyText')) $('copyText').classList.add('hidden');
});

if ($('doText')) if ($('doText')) $('doText').addEventListener('click', async () => {
  const mode = $('doText').dataset.mode || 'encrypt';
  try {
    if (mode === 'encrypt') {
      const txt = ($('textIn')?.value || '');
      let pubOverride=null; const sel=document.getElementById('recipientSelectPopup'); if(sel && sel.value!=='me'){ const arr=sel.selectedOptions[0]?.dataset?.kyberPub? JSON.parse(sel.selectedOptions[0].dataset.kyberPub): null; if(arr) pubOverride=new Uint8Array(arr); }
      const bundle = await pqcEncryptBytes(te.encode(txt), pubOverride);
      const j = JSON.stringify(bundle);
      if ($('textOut')) $('textOut').value = j;
      if ($('saveRow')) $('saveRow').classList.remove('hidden'); if ($('saveTextAs')) $('saveTextAs').classList.remove('hidden'); if ($('textOut')) $('textOut').classList.remove('hidden'); if ($('copyText')) $('copyText').classList.remove('hidden'); if ($('saveText')) $('saveText').classList.remove('hidden');
    } else {
      const j = ($('textIn')?.value || '').trim();
      const obj = JSON.parse(j);
      try{ if(obj.sig && obj.from){ const msg=new TextEncoder().encode(JSON.stringify({kemCt:obj.kemCt,iv:obj.iv,ct:obj.ct,ver:obj.ver,scheme:obj.scheme})); const ok=DSA_verify(unhex(obj.from), msg, unhex(obj.sig)); if(!ok) alert('WARNING: Signature INVALID'); } }catch(e){ console.warn('verify failed', e); }
      const pt = await pqcDecryptBytes(obj);
      if ($('textOut')) $('textOut').value = td.decode(pt);
      if ($('saveRow')) $('saveRow').classList.remove('hidden'); if ($('saveTextAs')) $('saveTextAs').classList.remove('hidden'); if ($('textOut')) $('textOut').classList.remove('hidden'); if ($('copyText')) $('copyText').classList.remove('hidden'); if ($('saveText')) $('saveText').classList.remove('hidden');
    }
  } catch (e) { alert(e.message || String(e)); }
});

if ($('saveText')) if ($('saveText')) $('saveText').addEventListener('click', async () => {
  try {
    const raw = ($('textOut')?.value || '').trim();
    const name = (($('saveTextAs')?.value) || 'message.pqc.json').trim();
    const blob = new Blob([raw], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    if (chrome?.downloads?.download) { chrome.downloads.download({ url, filename: name, saveAs: true }); setTimeout(()=>URL.revokeObjectURL(url),10000); }
    else { const a=document.createElement('a'); a.href=url; a.download=name; a.click(); setTimeout(()=>URL.revokeObjectURL(url),10000); }
  } catch(e) { alert(e.message||String(e)); }
});

if ($('copyText')) if ($('copyText')) $('copyText').addEventListener('click', async () => {
  try { await navigator.clipboard.writeText($('textOut').value); alert('Copied'); } catch {}
});

window.addEventListener('DOMContentLoaded', async ()=>{ await refreshUI(); await loadRecipientsPopup(); });


$('btnImportKeysPopup')?.addEventListener('click', () => {
  const i = document.getElementById('importPickerPopup'); if (!i) return;
  i.value=''; i.click();
});
$('importPickerPopup')?.addEventListener('change', async (e) => {
  const f = e.target.files?.[0]; if (!f) return;
  try {
    const txt = await f.text();
    const obj = JSON.parse(txt);
    const set = {};
    if (obj.kyber) set.kyber = obj.kyber;
    if (obj.dili)  set.dili  = obj.dili;
    if (obj.pinSalt) set.pinSalt = obj.pinSalt;
    if (obj.pinVerifier) set.pinVerifier = obj.pinVerifier;
    await chrome.storage.local.set(set);
    alert('Keys imported. You can now enter your PIN to use them.');
    await refreshUI();
  } catch (e2) {
    alert('Import failed: ' + (e2.message || String(e2)));
  }
});

async function loadRecipientsPopup(){
  const s = await sget(['contacts']);
  const sel = document.getElementById('recipientSelectPopup'); if (!sel) return;
  sel.innerHTML = '<option value="me">Me (Vault)</option>';
  const arr = Array.isArray(s.contacts)? s.contacts: [];
  for (const c of arr){
    const o = document.createElement('option'); o.value = c.id || c.name; o.textContent = c.name || c.id || 'Contact';
    o.dataset.kyberPub = c.kyberPub? JSON.stringify(c.kyberPub): '';
    sel.appendChild(o);
  }
}
