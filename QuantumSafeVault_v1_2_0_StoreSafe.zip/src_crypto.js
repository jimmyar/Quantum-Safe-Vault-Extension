
import { dbSet, dbGet } from './src_idb.js';

function rnd(n){ const a=new Uint8Array(n); crypto.getRandomValues(a); return a; }
const hex = (u8)=>[...u8].map(b=>b.toString(16).padStart(2,'0')).join('');

export async function generateKyber() {
  // Placeholder sizes (real ML‑KEM‑768 pk≈1184, sk≈2400). Using shorter bytes for demo.
  const pub = rnd(32);
  const prv = rnd(48);
  await dbSet('kyber.pub', pub);
  await dbSet('kyber.prv', prv);
  return { publicKey: pub, privateKey: prv };
}

export async function generateDilithium() {
  // Placeholder sizes (real ML‑DSA‑44 pk≈1312, sk≈2528). Using shorter bytes for demo.
  const pub = rnd(32);
  const prv = rnd(64);
  await dbSet('dilithium.pub', pub);
  await dbSet('dilithium.prv', prv);
  return { publicKey: pub, privateKey: prv };
}

export async function getPublicKeys() {
  const ky = await dbGet('kyber.pub');
  const di = await dbGet('dilithium.pub');
  return {
    kyber: ky ? hex(new Uint8Array(ky)) : '(none)',
    dilithium: di ? hex(new Uint8Array(di)) : '(none)'
  };
}
