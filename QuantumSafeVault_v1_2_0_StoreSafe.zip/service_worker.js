// Step 2A: no background logic yet
self.addEventListener('install',()=>{});
