
document.addEventListener('DOMContentLoaded', () => {
  const el = document.getElementById('openOptions');
  if (el) {
    el.addEventListener('click', (e) => {
      e.preventDefault();
      try { chrome.runtime.openOptionsPage(); } catch (err) { console.error(err); }
    });
  }
});
