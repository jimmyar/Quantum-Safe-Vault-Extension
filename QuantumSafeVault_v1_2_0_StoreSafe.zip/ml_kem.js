
import { ml_kem768 } from './vendor/post-quantum/ml-kem.js';
export const backend = 'noble 0.4.1';
export function kemKeypair() {
  const { publicKey, secretKey } = ml_kem768.keygen();
  return { pk: publicKey, sk: secretKey };
}
