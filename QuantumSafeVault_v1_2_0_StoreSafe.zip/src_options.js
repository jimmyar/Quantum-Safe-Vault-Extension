
import { ml_kem768 } from './vendor/post-quantum/ml-kem.js';
import { ml_dsa65 } from './vendor/post-quantum/ml-dsa.js';

async function encryptWithPIN(pin, plain) {
  const iv = crypto.getRandomValues(new Uint8Array(12));
  const salt = crypto.getRandomValues(new Uint8Array(16));
  const akey = await deriveAESKeyFromPIN(pin, salt);
  const ct = new Uint8Array(await crypto.subtle.encrypt({ name:'AES-GCM', iv }, akey, plain));
  return { ct:Array.from(ct), iv:Array.from(iv), salt:Array.from(salt) };
}

async function ensurePINInteractive() {
  const { pinSalt, pinVerifier } = await getStore(['pinSalt','pinVerifier']);
  if (!pinSalt || !pinVerifier) throw new Error('PIN not set. Generate a key in the popup first.');
  const pin = prompt('Enter your PIN to regenerate');
  if (!pin || pin.length < 1) throw new Error('PIN required');
  const bits = await deriveBitsFromPIN(pin, new Uint8Array(pinSalt));
  const digest = await sha256(bits);
  const ok = hex(digest) === hex(new Uint8Array(pinVerifier));
  if (!ok) throw new Error('Wrong PIN');
  return pin;
}

async function regenerateKyber() {
  const pin = await ensurePINInteractive();
  const { publicKey, secretKey } = ml_kem768.keygen();
  const bundle = await encryptWithPIN(pin, secretKey);
  await new Promise(res => chrome.storage.local.set({ kyber: { pub:Array.from(publicKey), prv: bundle }}, res));
  await load();
  alert('Kyber key regenerated');
}
async function regenerateDilithium() {
  const pin = await ensurePINInteractive();
  const { publicKey, secretKey } = ml_dsa65.keygen();
  const bundle = await encryptWithPIN(pin, secretKey);
  await new Promise(res => chrome.storage.local.set({ dili: { pub:Array.from(publicKey), prv: bundle }}, res));
  await load();
  alert('Dilithium key regenerated');
}

const hex = (u8) => [...u8].map(b => b.toString(16).padStart(2,'0')).join('');
const $ = (id) => document.getElementById(id);


const enc = new TextEncoder();
async function sha256(u8) { const d = await crypto.subtle.digest('SHA-256', u8); return new Uint8Array(d); }
async function deriveBitsFromPIN(pin, salt) {
  const keyMat = await crypto.subtle.importKey('raw', enc.encode(pin), 'PBKDF2', false, ['deriveBits']);
  const bits = await crypto.subtle.deriveBits({ name: 'PBKDF2', hash: 'SHA-256', iterations: 200_000, salt }, keyMat, 256);
  return new Uint8Array(bits);
}
async function deriveAESKeyFromPIN(pin, salt) {
  const bits = await deriveBitsFromPIN(pin, salt);
  return await crypto.subtle.importKey('raw', bits, { name: 'AES-GCM' }, false, ['encrypt', 'decrypt']);
}
async function decryptWithPIN(pin, bundle) {
  const { ct, iv, salt } = bundle;
  const akey = await deriveAESKeyFromPIN(pin, new Uint8Array(salt));
  const pt = new Uint8Array(await crypto.subtle.decrypt({ name:'AES-GCM', iv:new Uint8Array(iv) }, akey, new Uint8Array(ct)));
  return pt;
}

async function getStore(keys) {
  return new Promise(res => chrome.storage.local.get(keys, res));
}
async function clearAll() {
  return new Promise(res => chrome.storage.local.clear(res));
}
async function copy(text) {
  try { await navigator.clipboard.writeText(text); alert('Copied'); } catch {}
}
function put(id, text) {
  const el = $(id).querySelector('code') || $(id);
  el.textContent = text || '';
}

async function load() {
  const s = await getStore(null); // all keys
  const ky = s.kyber, di = s.dili;

  put('kyPub', ky?.pub ? hex(new Uint8Array(ky.pub)) : '(no key)');
  put('kyPrv', ky?.prv ? `(encrypted: ${ky.prv.ct.length} bytes)` : '(none)');

  put('diPub', di?.pub ? hex(new Uint8Array(di.pub)) : '(no key)');
  put('diPrv', di?.prv ? `(encrypted: ${di.prv.ct.length} bytes)` : '(none)');

  const metaLines = [];
  if (s.pinSalt)     metaLines.push(`pinSalt:     ${hex(new Uint8Array(s.pinSalt))}`);
  if (s.pinVerifier) metaLines.push(`pinVerifier: ${hex(new Uint8Array(s.pinVerifier))}`);
  put('meta', metaLines.join('\n') || '(empty)');

  // copy buttons
  $('copyKyPub').disabled = !ky?.pub;
  $('copyDiPub').disabled = !di?.pub;
  $('copyKyPub').onclick = () => copy(hex(new Uint8Array(ky.pub)));
  $('copyDiPub').onclick = () => copy(hex(new Uint8Array(di.pub)));
}

$('clear').addEventListener('click', async () => {
  if (!confirm('Delete all stored keys and PIN metadata?')) return;
  await clearAll();
  await load();
});

load();


document.getElementById('show').addEventListener('click', async () => {
  const pinInput = document.getElementById('pin');
  const pin = pinInput.value || '';
  if (pin.length < 1) { alert('Enter your PIN.'); return; }
  const { pinSalt, pinVerifier, kyber, dili } = await getStore(['pinSalt','pinVerifier','kyber','dili']);
  if (!pinSalt || !pinVerifier) { alert('No PIN is set yet. Generate a key first.'); return; }
  const bits = await deriveBitsFromPIN(pin, new Uint8Array(pinSalt));
  const digest = await sha256(bits);
  const ok = hex(digest) === hex(new Uint8Array(pinVerifier));
  if (!ok) { alert('Wrong PIN'); return; }
  try {
    let ky = '', di = '';
    if (kyber?.prv) ky = hex(await decryptWithPIN(pin, kyber.prv));
    if (dili?.prv) di = hex(await decryptWithPIN(pin, dili.prv));
    if (!ky && !di) alert('Nothing to decrypt yet.');
    if (ky) { const el = document.getElementById('kyPrv').querySelector('code'); el.textContent = ky; el.classList.remove('muted'); }
    if (di) { const el = document.getElementById('diPrv').querySelector('code'); el.textContent = di; el.classList.remove('muted'); }
  } catch(e) {
    alert(e.message || String(e));
  }
});

document.getElementById('regenKyber').addEventListener('click', async () => {
  try { await regenerateKyber(); } catch(e) { alert(e.message || String(e)); }
});
document.getElementById('regenDili').addEventListener('click', async () => {
  try { await regenerateDilithium(); } catch(e) { alert(e.message || String(e)); }
});


function download(name, text){
  const blob = new Blob([text], { type: 'text/plain' });
  const url = URL.createObjectURL(blob);
  if (chrome?.downloads?.download) {
    chrome.downloads.download({ url, filename: name, saveAs: true });
    setTimeout(() => URL.revokeObjectURL(url), 10000);
  } else {
    const a=document.createElement('a'); a.href=url; a.download=name; a.click();
    setTimeout(() => URL.revokeObjectURL(url), 10000);
  }
}

$('btnExportKeys').addEventListener('click', async () => {
  const s = await chrome.storage.local.get(['kyber','dili','pinSalt','pinVerifier']);
  const payload = {
    exportedAt: new Date().toISOString(),
    kyber: s.kyber || null,
    dili: s.dili || null,
    pinSalt: s.pinSalt || null,
    pinVerifier: s.pinVerifier || null
  };
  download('pqc-keys-export.json', JSON.stringify(payload, null, 2));
});

$('btnImportKeys').addEventListener('click', () => { const i=$('importPicker'); i.value=''; i.click(); });
$('importPicker').addEventListener('change', async (e) => {
  const f = e.target.files && e.target.files[0];
  if (!f) return;
  try {
    const text = await f.text();
    const obj = JSON.parse(text);
    const set = {};
    if (obj.kyber) set.kyber = obj.kyber;
    if (obj.dili)  set.dili  = obj.dili;
    if (obj.pinSalt) set.pinSalt = obj.pinSalt;
    if (obj.pinVerifier) set.pinVerifier = obj.pinVerifier;
    await chrome.storage.local.set(set);
    alert('Keys imported. You may need to re-open the popup.');
    location.reload();
  } catch (e) {
    alert('Import failed: ' + (e.message || String(e)));
  }
});


// ---- Sharing & Contacts ----
function downloadJSON(name, obj){
  const blob = new Blob([JSON.stringify(obj, null, 2)], {type:'application/json'});
  const url = URL.createObjectURL(blob);
  if (chrome?.downloads?.download) chrome.downloads.download({ url, filename: name, saveAs: true });
  else { const a=document.createElement('a'); a.href=url; a.download=name; a.click(); }
  setTimeout(()=>URL.revokeObjectURL(url), 10000);
}
function u8hex(u8){ return Array.from(u8).map(b=>b.toString(16).padStart(2,'0')).join(''); }
function asU8(x){ if (!x) return null; if (Array.isArray(x)) return new Uint8Array(x); if (typeof x==='string'){ const m=x.match(/.{1,2}/g)||[]; return new Uint8Array(m.map(h=>parseInt(h,16))); } return null; }

document.getElementById('btnExportMyPubs')?.addEventListener('click', async () => {
  const s = await chrome.storage.local.get(['kyber','dili']);
  const out = { name: 'My Public Keys', kyberPub: s.kyber?.pub||null, diliPub: s.dili?.pub||null };
  downloadJSON('my-public-keys.json', out);
});
document.getElementById('btnCopyMyPubs')?.addEventListener('click', async () => {
  const s = await chrome.storage.local.get(['kyber','dili']);
  const out = { kyberPub: s.kyber?.pub||null, diliPub: s.dili?.pub||null };
  try { await navigator.clipboard.writeText(JSON.stringify(out)); alert('Copied'); } catch {}
});

async function renderContacts(){
  const s = await chrome.storage.local.get(['contacts']);
  const list = Array.isArray(s.contacts) ? s.contacts : [];
  const el = document.getElementById('contactsTable');
  if (!el) return;
  if (!list.length){ el.innerHTML = '<div class="muted">No contacts yet.</div>'; return; }
  el.innerHTML = '<table style="width:100%;border-collapse:collapse;font-size:13px"><thead><tr><th align="left">Name</th><th align="left">Kyber pub (short)</th><th align="left">Dilithium pub (short)</th><th></th></tr></thead><tbody>' +
    list.map((c,i)=>{
      const k = (typeof c.kyberPub==='string'? c.kyberPub : u8hex(new Uint8Array(c.kyberPub||[])));
      const d = c.diliPub ? (typeof c.diliPub==='string'? c.diliPub : u8hex(new Uint8Array(c.diliPub))) : '';
      return `<tr><td>${c.name||'(unnamed)'}</td><td><code>${k.slice(0,16)}…</code></td><td><code>${d?d.slice(0,16)+'…':''}</code></td><td><button data-i="${i}" class="btn secondary">Remove</button></td></tr>`;
    }).join('') + '</tbody></table>';
  el.querySelectorAll('button[data-i]').forEach(btn=>{
    btn.addEventListener('click', async ()=>{
      const i = +btn.getAttribute('data-i');
      const s2 = await chrome.storage.local.get(['contacts']);
      const arr = Array.isArray(s2.contacts) ? s2.contacts : [];
      arr.splice(i,1);
      await chrome.storage.local.set({ contacts: arr });
      renderContacts();
    });
  });
}

document.getElementById('btnImportContact')?.addEventListener('click', () => {
  const i = document.getElementById('contactPicker'); i.value=''; i.click();
});
document.getElementById('contactPicker')?.addEventListener('change', async (e) => {
  const f = e.target.files?.[0]; if (!f) return;
  try {
    const text = await f.text();
    const obj = JSON.parse(text);
    const name = obj.name || obj.alias || prompt('Contact name?') || 'Contact';
    const kp = asU8(obj.kyberPub);
    if (!kp) throw new Error('Missing kyberPub');
    const dp = asU8(obj.diliPub);
    const id = obj.id || (crypto.randomUUID?.() || (Date.now()+'-'+Math.random()));
    const s = await chrome.storage.local.get(['contacts']);
    const arr = Array.isArray(s.contacts) ? s.contacts : [];
    arr.push({ id, name, kyberPub: Array.from(kp), diliPub: dp? Array.from(dp): null });
    await chrome.storage.local.set({ contacts: arr });
    alert('Contact added: ' + name);
    renderContacts();
  } catch (e) { alert('Import failed: ' + (e.message || String(e))); }
});
document.getElementById('btnClearContacts')?.addEventListener('click', async ()=>{
  if (!confirm('Clear all contacts?')) return;
  await chrome.storage.local.set({ contacts: [] });
  renderContacts();
});

window.addEventListener('DOMContentLoaded', renderContacts);
